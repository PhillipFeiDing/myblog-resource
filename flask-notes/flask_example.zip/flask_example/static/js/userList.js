// Send GET request
function get(url) {
    return $.get(url)
}

// Send POST request
function post(url, data = {}) {
    return $.ajax({
        type: 'post',
        url,
        data: JSON.stringify(data),
        contentType: "application/json",
    })
}

get('/get-user-list').then(res => {
    fillTable(res)
})

$('#filter-button').on('click', () => {
    const username = $('#username-input').val()
    const firstName = $('#first-name-input').val()
    let args = ''
    if (username !== '') {
        args += 'username=' + username
    }
    if (firstName !== '') {
        if (args !== '') {
            args += '&'
        }
        args += 'firstName=' + firstName
    }
    if (args !== '') {
        args = '?' + args
    }
    get('/get-user-list' + args).then(res => {
        fillTable(res)
    })
})

function fillTable(res) {
    if (res.status == 0) {
        $('#user-list-table').html(`
            <tr>
                    <th>Username</th>
                    <th>Password</th>
                    <th>First Name</th>
                    <th>Last Name</th>
            </tr>
        `)
        res.data.forEach((row) => {
            $('#user-list-table').append(`
                <tr>
                    <td>${row.username}</td>
                    <td>${row.password}</td>
                    <td>${row['first_name']}</td>
                    <td>${row['last_name']}</td>
                <tr>
            `)
        })
    } else {
        window.alert(res.err)
    }
}