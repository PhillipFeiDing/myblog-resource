// Send GET request
function get(url) {
    return $.get(url)
}

// Send POST request
function post(url, data = {}) {
    return $.ajax({
        type: 'post',
        url,
        data: JSON.stringify(data),
        contentType: "application/json",
    })
}

$('#submit-button').on('click', () => {
    const username = $('#username-input').val()
    const password = $('#password-input').val()
    const firstName = $('#first-name-input').val()
    const lastName = $('#last-name-input').val()
    const data = {
        'username': username,
        'password': password,
        'firstName': firstName,
        'lastName': lastName
    }
    post('/db-op', data).then((res) => {
        if (res.status == 0) { // success
            window.alert('success')
            window.location.href = '/user-list'
        } else { // error
            window.alert(res.err)
        }
    })
})