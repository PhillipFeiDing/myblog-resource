import pymysql.cursors
from flask import Flask, request, render_template, url_for, jsonify


app = Flask(__name__)


# build connection with MySQL
connection = pymysql.connect(host='localhost',
                         user='root',
                         password='997971',
                         db='gt_food_truck',
                         charset='utf8mb4',
                         cursorclass=pymysql.cursors.DictCursor)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/user-list')
def userList():
    return render_template('userList.html')


@app.route('/db-op', methods=['POST'])
def register():
    data = request.get_json()
    username = data['username']
    password = data['password']
    firstName = data['firstName']
    lastName = data['lastName']
    try:
        with connection.cursor() as cursor:
            sql = 'INSERT INTO `user` (`username`, `password`, `first_name`, `last_name`) ' \
            + 'VALUES (%s, %s, %s, %s);'
            cursor.execute(sql, (username, password, firstName, lastName))
            connection.commit()
        return jsonify({
            'status': 0
        })
    except Exception as e:
        return jsonify({
            'status': 1,
            'err': str(e)
        })


@app.route('/get-user-list', methods=['GET'])
def getUserList():
    username = request.args.get('username')
    firstName = request.args.get('firstName')
    try:
        with connection.cursor() as cursor:
            sql = 'SELECT * FROM `user` WHERE 1 = 1'
            if username:
                sql = sql + ' AND `username` LIKE "%{}%"'.format(username)
            if firstName:
                sql = sql + ' AND `first_name` LIKE "%{}%"'.format(firstName)
            sql = sql + ';'
            cursor.execute(sql)
            data = cursor.fetchall()
        return jsonify({
            'status': 0,
            'data': data
        })
    except Exception as e:
        return jsonify({
            'status': 1,
            'err': str(e)
        })


# connection.close() # You will never have to call this!


if __name__ == '__main__':
    app.run(debug=True)